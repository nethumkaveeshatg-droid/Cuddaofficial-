CUDDA OFFICIAL WEBSITE

FILES
- index.html : complete responsive website
- hero.jpg   : your supplied image used on the homepage

HOW TO TEST
1. Extract the ZIP.
2. Open index.html in a modern browser.
3. Internet access is needed for picture search (Wikimedia Commons API).

HOW TO PUBLISH FOR FREE (GitHub Pages)
1. Sign in at https://github.com/ and create a new repository.
2. Upload index.html and hero.jpg to the repository root.
3. Open Settings -> Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select the main branch and /(root), then Save.
6. Wait for GitHub Pages to publish the site and open the URL shown there.

NOTES
- The picture search uses Wikimedia Commons and requires internet access.
- Results link to original files and their file pages. Check license and attribution terms before reusing images.
- This is a front-end website; it does not upload pictures to a private server.
